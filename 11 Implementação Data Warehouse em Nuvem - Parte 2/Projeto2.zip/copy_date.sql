copy dimdate
from ''
iam_role '' 
region ''
json as 'auto'
