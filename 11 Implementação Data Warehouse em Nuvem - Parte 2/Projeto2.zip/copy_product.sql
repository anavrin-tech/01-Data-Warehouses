copy dimproduct
from '' 
iam_role '' 
region ''
delimiter ','