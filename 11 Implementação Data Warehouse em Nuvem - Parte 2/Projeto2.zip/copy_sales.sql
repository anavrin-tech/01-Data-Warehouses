copy factsales
from '' 
iam_role '' 
region ''
delimiter '|'
GZIP 
manifest
  
